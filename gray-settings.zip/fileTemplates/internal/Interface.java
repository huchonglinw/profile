#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author: chonglin.hu
 * @date: ${DATE} ${TIME}
 */
public interface ${NAME} {
}
